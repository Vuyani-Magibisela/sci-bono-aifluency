# Handoff: AI Fluency Course — "AI Foundations" Module (Gamified)

## Overview
A gamified, single-player learning experience for the **Sci-Bono AI Hub Platform**. It teaches AI fundamentals to learners through short, badge-earning "missions." There are two deliverables in this bundle:

1. **AI History Journey** — a 70-year time-travel "intro mission" (eras → quizzes → reward).
2. **AI Foundations** — Module 1: a hub of 4 missions, each a multi-step chapter (intro → concept cards → quizzes → a mini-game → reward), with XP, progress dots, badges, and a robot mascot guide.

The whole experience is a Duolingo-style, dark-space-themed, kid/teen-friendly flow built around **XP, badges, streak-of-steps progress, and instant feedback**.

## About the Design Files
The files in this bundle are **design references created in HTML** — high-fidelity prototypes showing the intended look, content, and behavior. They are **not production code to copy directly**.

Your task is to **recreate these designs inside the Sci-Bono AI Hub Platform's existing environment**, using its established framework, component library, routing, state, and persistence patterns. If the platform has no front-end environment yet, choose the most appropriate framework (e.g. React) and implement there. The HTML uses a small custom runtime (`support.js`, an `x-dc` template layer) that you should **not** carry over — reimplement the UI natively.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, copy, animations, and interactions are all specified below and present in the prototypes. Recreate the UI faithfully, then swap in the platform's own primitives (buttons, cards, layout, persistence) where they exist.

---

## Screens / Views

### A. Module Hub ("AI Foundations")
- **Purpose**: Landing screen for Module 1. Learner sees overall progress and picks a mission.
- **Layout**: Full-height column. Top header bar; centered main with a title block, a stats row, and a 2-column card grid (`grid-template-columns: repeat(2, minmax(264px, 300px)); gap: 20px`).
- **Components**:
  - **Header** (shared across all screens): white rounded logo chip (`assets/sci-bono-logo.png`, 30px tall) + "SCI-BONO AI HUB" eyebrow on the left; centered context label ("Module 1 · AI Foundations"); **XP pill** on the right (gold gradient, lightning glyph, "{xp} XP").
  - **Title block**: pill badge "Module 1 · 4 Missions" (cyan outline); H1 "AI Foundations" (`Baloo 2`, 800, clamp(40–62px), white, cyan text-shadow); subtitle paragraph (`Nunito`, 600, 17px, `#9db8d8`).
  - **Stats row**: "{n} / 4 complete" and "{xp} XP total" separated by a divider.
  - **Mission cards** (5 total: 1 History card + 4 chapter cards). Each card: `background: rgba(8,26,52,0.55)`, `border: 1px solid rgba(255,255,255,0.12)`, `border-radius: 18px`, `padding: 20px 22px 18px 26px`, a 5px accent stripe down the left edge. Contains: number pill (accent bg), status text (Start/Completed/Open), H3 title (`Baloo 2`, 800, 21px), blurb, footer row with status text + chevron in accent color. Completed cards get a green border tint + "Completed" / "{xp} XP earned".
  - **Hover**: `translateY(-4px)` + larger shadow.

### B. Chapter / Mission Flow (shared shell)
Each chapter runs inside a centered **stage card**: `width: min(1140px, 95vw); height: min(660px, 80vh); border-radius: 28px`, deep-blue radial gradient, faint grid overlay (masked), floating accent dots (`drift` animation), big shadow. Header changes to show **progress dots** (one per step; current step enlarges to 26px and shows its number) and the chapter label ("Chapter 1.01 · What is AI?"). A **"Module" back button** sits top-left of the stage. A **robot mascot** ("Bono") with a speech bubble sits bottom-right during intro/concept/quiz/game steps, giving contextual encouragement and hints.

Step types within a chapter (order defined per chapter):
1. **Intro** — kicker pill, big multi-line title (`Baloo 2`, clamp(38–72px), `white-space: pre-line`), tagline, body, primary CTA.
2. **Concept** — "Concept X of N" label; a row with a **spinning-ring medallion** holding a line-icon (170px circle, accent glow) + a text column (tag pill, H2 title 30px, body 18px). Optional **definition box** (accent-tinted, 4px left border) with a term + definition. Continue button awards XP.
3. **Quiz** — "Challenge" eyebrow; question H2; 2-column grid of answer buttons, each with a letter badge (A–D). Correct → green check + locks; wrong → red X, mascot gives a hint (if `showHints`). Continue appears once solved. First correct answer awards 20 XP.
4. **Mini-game** (one per chapter, see below).
5. **Reward** — confetti burst, pulsing trophy/medal SVG, "Chapter X Complete!", three stat chips (XP / Concepts / Badge), then "Next Chapter" + "Play Again" buttons.

### C. Mini-games
- **Turing Test ("Human or Machine?")** — chapter 1.01. A list of chat-bubble messages; for each, learner taps **Human** or **Machine**. Once all answered, "Reveal the Answers" shows per-round correctness + explanation and a summary lesson. Awards 15 XP.
- **Sort It ("Knowledge or Intelligence?")** — chapter 1.02. **Drag-and-drop**: draggable chips from a pool into two labeled bins. Correct drop locks the item into the bin (green) + awards 10 XP each; wrong drop shakes the bin. Continue appears when pool is empty.
- **Data Explosion** — chapter 1.03. A **range slider** (years 1990→2024). Dragging updates a growing vertical bar, a "≈ {x} ZB" volume readout (exponential growth `0.001 * 1.42^(year-1990)`), the year, and a caption. Reaching 2024 marks done + awards 15 XP.

### D. AI History Journey (separate file)
Same shell and visual language. A single linear flow of **12 steps**: a Start screen, then alternating **Era** cards (year medallion + tag + title + one-line description) and **Quiz** challenges, ending in a **Reward**. XP and progress dots as above. The Hub's first card ("1.00 AI History Journey") links to this file.

---

## Interactions & Behavior
- **Navigation**: Hub → chapter (set view, reset step state) → step-by-step `next()` advancing `stepIndex`. Reward "Next Chapter" jumps to next chapter or back to hub (with a celebratory toast on module completion). Back button returns to hub.
- **XP awards**: concept continue +10, correct quiz +20 (first time only), Turing reveal +15, each correct sort +10, slider-to-2024 +15. Awards trigger a floating "+N XP" burst over the XP pill (`xpfloat` animation, 1.2s).
- **Idempotency**: each XP source is keyed (`c{stepIndex}`, `q{stepIndex}`, `g`) so replaying/re-answering doesn't double-count within a run.
- **Per-chapter run XP** is committed to the saved total on reaching the reward step (`Math.max` of previous best and this run).
- **Animations**: step transitions `risein`/`pop` (~0.45s ease-out); mascot `bob` (3.4s) + glowing eyes `glow`; medallion ring `spin` (7s linear); reward trophy `pulse` (2.2s); confetti `fall`; bins `shake` on wrong drop; floating dots `drift`.
- **Toast**: bottom-center, auto-dismiss ~3.2s.
- **Hover states**: cards lift; buttons lift (`translateY(-2/-3px)`); secondary button bg lightens.

## State Management
Per-component state needed (names from the prototype):
- `view` ('hub' | 'chapter'), `ci` (chapter index), `stepIndex`.
- `runXp` (XP this run), `earned` (map of awarded keys), `burst` (floating XP indicator).
- `completed` (map chapterId→bool) and `chapterXp` (map chapterId→best XP) — **the only persisted state**.
- Quiz: `quizPick`, `quizDone`. Turing: `turing` (round→pick), `turingRevealed`. Sort: `sortAssign` (item→bin), `sortShake`. Slider: `sliderYear`, `sliderDone`. `toast`.
- **Persistence**: `completed` + `chapterXp` saved to `localStorage` key `sciBonoAIFoundations_v1`. In the platform, persist this **per-user via the platform's user/progress store** instead of localStorage, so progress follows the account.

## Design Tokens
**Colors**
- Background gradient: `#0b2c52 → #061a33 → #03101f` (radial).
- Stage gradient: `#15538f → #0c3566 → #06203f`.
- Surface card: `rgba(8,26,52,0.55)`; panel dark `#08203f`; borders `rgba(255,255,255,0.12–0.16)`.
- Text: white `#fff`; primary blue-white `#cfe2f7` / `#eaf3ff`; muted `#9db8d8`; dim `#7e9cc4` / `#6f8cb0`.
- Brand/XP gold: `#F4B740` (default `accent` prop).
- Accents per chapter: 1.01 `#4f9bff`, 1.02 `#2fd4dd`, 1.03 `#ff9b54`, History `#F4B740`.
- Semantic: correct green `#34c759` / `#7ee0a0`; wrong red `#ff5a5f`; cyan `#2fd4dd`; orange `#ff9b54`.
- Confetti palette: `#F4B740 #2fd4dd #4f9bff #ff7a8a #7ee0a0 #c08bff`.

**Typography** — Google Fonts: **Baloo 2** (600/700/800, display/headings/buttons) + **Nunito** (600/700/800, body/labels).
- H1 hub `clamp(40–62px)`; intro big `clamp(38–72px)`; H2 `~30px`; body `17–20px`; labels/eyebrows `12–13px` uppercase, letter-spacing `1.5–2px`.

**Radius**: cards 18px; stage 28px; pills 999px; buttons 18px; def box 14px.
**Shadows**: cards `0 20px 44px rgba(0,0,0,0.5)` (hover); stage `0 30px 70px rgba(0,0,0,0.5)`; primary button has a chunky bottom shadow `0 7px 0 {darkened accent}` for a tactile "key" look.
**Spacing**: header padding `18px 30px`; card grid gap `20px`; stage inner padding `24–56px`.

## Tweakable Props (exposed on the root component)
- `accent` (color, default `#F4B740`) — global brand/XP color.
- `mascotName` (text, default `Bono`) — robot guide's name.
- `showHints` (boolean, default `true`) — whether wrong quiz answers reveal a hint.

## Assets
- `assets/sci-bono-logo.png` — Sci-Bono Discovery Centre logo (used in the header chip on a white background). Included in this bundle. Use the platform's official logo asset if one exists.
- All icons (concept line-icons, lightning/XP glyph, trophy, robot mascot, checks/crosses) are **inline SVG** drawn in code — recreate as SVG/icon components; no external icon files.

## Content
All learning copy (chapter titles, concept text, definitions, quiz questions + answers + hints, mini-game data, badges) is authored in the `CHAPTERS` array inside `AI Foundations.dc.html`, and the eras/quizzes in `AI History Journey.dc.html`. Treat that content as the source of truth — lift it verbatim. Recommend moving it into the platform's CMS / content store rather than hardcoding.

## Files
- `AI Foundations.dc.html` — Module 1 hub + 3 interactive chapters (with mini-games, XP, badges).
- `AI History Journey.dc.html` — the intro "1.00" time-travel mission.
- `assets/sci-bono-logo.png` — logo asset.
- `support.js` — the prototype runtime (reference only; **do not port**).
